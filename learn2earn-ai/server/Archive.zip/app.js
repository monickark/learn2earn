// server/app.js
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';

import generateContentRoute from './routes/generateContent.js';

process.on('uncaughtException', (err) => {
  console.error('❌ UNCAUGHT EXCEPTION:', err);
});

process.on('unhandledRejection', (err) => {
  console.error('❌ UNHANDLED PROMISE REJECTION:', err);
});

dotenv.config();
console.log("[dotenv] Loaded environment variables");


// ✅ Debug Azure OpenAI keys
console.log("AZURE_OPENAI_KEY present:", !!process.env.AZURE_OPENAI_KEY);
console.log("AZURE_OPENAI_ENDPOINT:", process.env.AZURE_OPENAI_ENDPOINT);
console.log("AZURE_OPENAI_DEPLOYMENT_NAME:", process.env.AZURE_OPENAI_DEPLOYMENT_NAME);
console.log("AZURE_OPENAI_API_VERSION:", process.env.AZURE_OPENAI_API_VERSION);

const app = express();

// ✅ Middleware
app.use(cors());
app.use(express.json());

// ✅ Routes
app.use('/api/generate-content', generateContentRoute);


// ✅ Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
