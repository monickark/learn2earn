// File: server/utils/formatResponse.js
export default function formatResponse(text) {
  return text;
  // Optionally parse and structure the content here
};

