// components/interview/Step2RoundsSelection.jsx
export default function Step2RoundsSelection({
  formData = {},
  rounds,
  selectedRounds,
  setSelectedRounds,
  onSubmit,
  loading
}) {
  const toggleSelection = (round) => {
    if (selectedRounds.includes(round)) {
      setSelectedRounds(selectedRounds.filter((r) => r !== round));
    } else {
      setSelectedRounds([...selectedRounds, round]);
    }
  };

  const skillsArray = (formData?.skills || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Step Header */}
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-indigo-100 flex items-center justify-center">
          <span className="text-indigo-700 text-lg">🎯</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-gray-900">
          Step 2: Select Interview Rounds
        </h2>
      </div>

      {/* Job Information Card */}
      {/* ... unchanged ... */}

      {/* Rounds List */}
      <div className="grid md:grid-cols-2 gap-5">
        {Array.isArray(rounds) && rounds.length > 0 ? (
          rounds.map((round, idx) => {
            const selected = selectedRounds.includes(round);
            return (
              <button
                type="button"
                key={idx}
                onClick={() => toggleSelection(round)}
                className={`group text-left rounded-xl border p-5 shadow-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transform ${
                  selected
                    ? "border-transparent bg-gradient-to-r from-indigo-500 to-purple-500 text-white scale-[1.02] shadow-lg"
                    : "bg-white hover:bg-gray-50 border-gray-200"
                }`}
              >
                {/* Round content ... unchanged ... */}
              </button>
            );
          })
        ) : (
          <p className="text-gray-500">No rounds available.</p>
        )}
      </div>

      {/* Submit Button - now just placed normally below */}
      <div className="mt-6">
        <button
          onClick={onSubmit}
          disabled={loading || selectedRounds.length === 0}
          className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 px-4 rounded-xl shadow-md transition-transform duration-200 hover:scale-[1.01]"
        >
          {loading ? "Loading..." : "Fetch Learning Content"}
        </button>
      </div>
    </div>
  );
}
