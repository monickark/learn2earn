import { useState } from "react";

export default function Step3LearningTabs({ learningContent }) {
  const [activeTab, setActiveTab] = useState(0);

  if (!learningContent || learningContent.length === 0) {
    return <p className="text-gray-500">No content available.</p>;
  }

  const round = learningContent[activeTab];

  return (
    <div className="max-w-4xl mx-auto">
      {/* Tab Selector */}
      <div className="flex border-b mb-4 overflow-x-auto">
        {learningContent.map((r, idx) => (
          <button
            key={idx}
            onClick={() => setActiveTab(idx)}
            className={`px-4 py-2 whitespace-nowrap ${
              idx === activeTab
                ? "border-b-2 border-indigo-600 font-bold text-indigo-700"
                : "text-gray-600 hover:text-indigo-600"
            }`}
          >
            {r.round}
          </button>
        ))}
      </div>

      {/* Content Card */}
      <div className="bg-white p-5 rounded-xl shadow space-y-4">
        <h3 className="text-xl font-bold text-indigo-700">{round.round}</h3>

        {/* Overview */}
        {round.Overview && (
          <p className="text-gray-700 leading-relaxed">{round.Overview}</p>
        )}

        {/* Must-Know Topics */}
        {Array.isArray(round.MustKnowTopics) && round.MustKnowTopics.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">
              📌 Must-Know Topics
            </h4>
            <ul className="list-disc ml-5 space-y-1">
              {round.MustKnowTopics.map((topic, i) => (
                <li key={i}>{topic}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Study Plan */}
        {Array.isArray(round.StudyPlan) && round.StudyPlan.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">📅 Study Plan</h4>
            <ol className="list-decimal ml-5 space-y-1">
              {round.StudyPlan.map((step, i) => (
                <li key={i}>{step}</li>
              ))}
            </ol>
          </div>
        )}

        {/* Sample Questions */}
        {Array.isArray(round.Questions) && round.Questions.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">
              ❓ Sample Questions
            </h4>
            <div className="space-y-3">
              {round.Questions.map((q, i) => (
                <div
                  key={i}
                  className="border border-gray-200 rounded-lg p-3 bg-gray-50"
                >
                  <p className="font-medium">{q.question}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    {q.sampleAnswer}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Mistakes to Avoid */}
        {Array.isArray(round.MistakesToAvoid) && round.MistakesToAvoid.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">
              ⚠️ Mistakes to Avoid
            </h4>
            <ul className="list-disc ml-5 space-y-1 text-red-600">
              {round.MistakesToAvoid.map((m, i) => (
                <li key={i}>{m}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Recommended Resources */}
        {Array.isArray(round.RecommendedResources) &&
          round.RecommendedResources.length > 0 && (
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">
                📚 Recommended Resources
              </h4>
              <ul className="space-y-1">
                {round.RecommendedResources.map((link, i) => (
                  <li key={i}>
                    <a
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:underline"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
      </div>
    </div>
  );
}
