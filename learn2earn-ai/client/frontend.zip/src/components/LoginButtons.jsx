import { loginWithWeb5 } from '../utils/web5Login';
import { supabase } from '../utils/supabaseClient';

export default function LoginButtons() {
  const handleSocialLogin = async (provider) => {
    await supabase.auth.signInWithOAuth({ provider });
  };

  return (
    <div className="flex flex-col gap-3 max-w-sm mx-auto">
      <button onClick={loginWithWeb5} className="btn">Login with Web5</button>
      <button onClick={() => handleSocialLogin('google')} className="btn">Login with Google</button>
      <button onClick={() => handleSocialLogin('github')} className="btn">Login with GitHub</button>
    </div>
  );
}
